import { Types } from "mongoose";
import { IProduct } from "../interfaces/product.interface";
import ProductModel from "../models/product.model";

class ProductService {
    async createJobApplication (data : IProduct): Promise<IProduct> {
        try {
            const response = await ProductModel.create(data);
            return response 
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    async getAllApplications(): Promise<IProduct[]> {
        try {
            const response = await ProductModel.find({});
            return response as IProduct[]; // Assuming response is an array of products
        } catch (error) {
            console.error('Error fetching products:', error);
            throw error; // Re-throw the error to handle it in the calling function
        }
    }

    async getJobApplicationsById(adminId: string): Promise<IProduct[]> {
        try {
            const response = await ProductModel.find({ adminId });
            return response as IProduct[]; // Assuming response is an array of products
        } catch (error) {
            console.error('Error fetching products:', error);
            throw error; // Re-throw the error to handle it in the calling function
        }
    }
}

export const productServices = new ProductService();